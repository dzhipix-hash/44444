
import sys, sqlite3, asyncio, csv, json
from pathlib import Path
from datetime import datetime
from PySide6.QtWidgets import *
from PySide6.QtCore import QThread, Signal
from telethon import TelegramClient
from telethon.errors import FloodWaitError, SessionPasswordNeededError
import socks

APP_DIR = Path.home() / "TelegramParser"
APP_DIR.mkdir(exist_ok=True)
SESSIONS = APP_DIR / "sessions"
DATA = APP_DIR / "data"
SESSIONS.mkdir(exist_ok=True)
DATA.mkdir(exist_ok=True)
DB = DATA / "parser.sqlite3"

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS accounts(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
      api_id INTEGER NOT NULL, api_hash TEXT NOT NULL, phone TEXT NOT NULL,
      proxy_host TEXT, proxy_port INTEGER, proxy_user TEXT, proxy_pass TEXT,
      session TEXT NOT NULL)""")
    c.commit()
    return c

def make_proxy(r):
    if not r["proxy_host"] or not r["proxy_port"]:
        return None
    return (socks.SOCKS5, r["proxy_host"], int(r["proxy_port"]), True,
            r["proxy_user"] or None, r["proxy_pass"] or None)

class Worker(QThread):
    log = Signal(str)
    dialogs = Signal(object)
    rows = Signal(object)
    code_needed = Signal(object)
    password_needed = Signal(object)

    def __init__(self, row, mode, payload=None):
        super().__init__()
        self.row, self.mode, self.payload = row, mode, payload or {}
        self.code = None
        self.password = None
        self.cancelled = False

    def run(self):
        asyncio.run(self.main())

    async def wait_value(self, attr):
        for _ in range(600):
            if self.cancelled:
                return None
            value = getattr(self, attr, None)
            if value:
                return value
            await asyncio.sleep(.25)
        return None

    async def main(self):
        r = self.row
        client = TelegramClient(
            str(SESSIONS / r["session"]),
            int(r["api_id"]),
            r["api_hash"],
            proxy=make_proxy(r)
        )
        try:
            await client.connect()

            if not await client.is_user_authorized():
                self.log.emit("Отправляем код Telegram...")
                await client.send_code_request(r["phone"])
                self.code_needed.emit(self)
                code = await self.wait_value("code")
                if not code:
                    self.log.emit("Авторизация отменена.")
                    return
                try:
                    await client.sign_in(r["phone"], code)
                except SessionPasswordNeededError:
                    self.password_needed.emit(self)
                    password = await self.wait_value("password")
                    if not password:
                        self.log.emit("Ввод 2FA отменён.")
                        return
                    await client.sign_in(password=password)
                self.log.emit("Авторизация успешна.")

            if self.mode == "dialogs":
                result = []
                async for d in client.iter_dialogs():
                    result.append({"id": d.id, "name": d.name or str(d.id)})
                self.dialogs.emit(result)
                self.log.emit(f"Загружено диалогов: {len(result)}")

            elif self.mode == "parse":
                result = []
                keyword = self.payload["keyword"].strip().lower()
                async for m in client.iter_messages(
                    self.payload["chat"], limit=self.payload["limit"]
                ):
                    text = m.message or ""
                    if keyword and keyword not in text.lower():
                        continue
                    sender = ""
                    if m.sender:
                        sender = (
                            getattr(m.sender, "username", None)
                            or getattr(m.sender, "first_name", None)
                            or str(getattr(m.sender, "id", ""))
                        )
                    result.append({
                        "account": r["name"],
                        "chat": str(self.payload["chat"]),
                        "message_id": m.id,
                        "sender": sender,
                        "date": m.date.isoformat() if m.date else "",
                        "text": text
                    })
                self.rows.emit(result)
                self.log.emit(f"Собрано сообщений: {len(result)}")

        except FloodWaitError as e:
            self.log.emit(
                f"Telegram установил FloodWait на {e.seconds} сек. "
                "Операция остановлена."
            )
        except Exception as e:
            self.log.emit(f"Ошибка: {type(e).__name__}: {e}")
        finally:
            await client.disconnect()

class AccountDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Добавить аккаунт")
        self.resize(500, 430)
        f = QFormLayout(self)
        self.name = QLineEdit()
        self.api = QLineEdit()
        self.hash = QLineEdit()
        self.phone = QLineEdit()
        self.host = QLineEdit()
        self.port = QLineEdit()
        self.user = QLineEdit()
        self.pw = QLineEdit()
        self.pw.setEchoMode(QLineEdit.Password)
        for label, widget in [
            ("Название", self.name), ("API ID", self.api),
            ("API HASH", self.hash), ("Телефон", self.phone),
            ("SOCKS5 host", self.host), ("SOCKS5 port", self.port),
            ("Proxy username", self.user), ("Proxy password", self.pw)
        ]:
            f.addRow(label, widget)
        f.addRow(QLabel("Прокси можно оставить пустым."))
        b = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        b.accepted.connect(self.accept)
        b.rejected.connect(self.reject)
        f.addRow(b)

    def values(self):
        return {
            "name": self.name.text().strip(),
            "api_id": int(self.api.text()),
            "api_hash": self.hash.text().strip(),
            "phone": self.phone.text().strip(),
            "host": self.host.text().strip(),
            "port": int(self.port.text() or 0),
            "user": self.user.text().strip(),
            "pw": self.pw.text()
        }

class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Telegram Parser")
        self.resize(1100, 720)
        self.con = db()
        self.worker = None
        self.results = []
        self.build()

    def build(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)

        menu = self.menuBar()
        a = menu.addMenu("Аккаунты")
        a.addAction("Добавить", self.add_account)
        a.addAction("Удалить", self.remove_account)
        a.addAction("Авторизовать", self.authorize)

        p = menu.addMenu("Парсер")
        p.addAction("Загрузить диалоги", self.load_dialogs)
        p.addAction("Начать парсинг", self.parse)

        e = menu.addMenu("Экспорт")
        e.addAction("CSV", self.export_csv)
        e.addAction("JSON", self.export_json)

        top = QHBoxLayout()
        self.accounts = QListWidget()
        self.accounts.setFixedWidth(300)
        top.addWidget(self.accounts)

        controls = QVBoxLayout()
        self.info = QLabel("Выберите аккаунт")
        controls.addWidget(self.info)

        controls.addWidget(QLabel("Чат / канал"))
        self.chat = QComboBox()
        self.chat.setEditable(True)
        controls.addWidget(self.chat)

        controls.addWidget(QLabel("Количество сообщений"))
        self.limit = QSpinBox()
        self.limit.setRange(1, 100000)
        self.limit.setValue(1000)
        controls.addWidget(self.limit)

        controls.addWidget(QLabel("Ключевое слово"))
        self.keyword = QLineEdit()
        controls.addWidget(self.keyword)

        for text, fn in [
            ("＋ Добавить аккаунт", self.add_account),
            ("🔐 Авторизовать", self.authorize),
            ("📂 Загрузить диалоги", self.load_dialogs),
            ("▶ Начать парсинг", self.parse),
            ("💾 Экспорт CSV", self.export_csv),
            ("💾 Экспорт JSON", self.export_json)
        ]:
            b = QPushButton(text)
            b.clicked.connect(fn)
            controls.addWidget(b)
        controls.addStretch()
        top.addLayout(controls)
        root.addLayout(top)

        root.addWidget(QLabel("Журнал"))
        self.logbox = QTextEdit()
        self.logbox.setReadOnly(True)
        self.logbox.setMaximumHeight(150)
        root.addWidget(self.logbox)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Аккаунт", "Чат", "ID", "Отправитель", "Дата", "Текст"]
        )
        self.table.horizontalHeader().setStretchLastSection(True)
        root.addWidget(self.table)

        self.accounts.currentItemChanged.connect(self.selected_changed)
        self.load_accounts()

    def log(self, text):
        self.logbox.append(text)

    def load_accounts(self):
        self.accounts.clear()
        for r in self.con.execute("SELECT * FROM accounts ORDER BY id"):
            item = QListWidgetItem(f"{r['name']}  |  {r['phone']}")
            item.setData(256, r["id"])
            self.accounts.addItem(item)

    def current(self):
        item = self.accounts.currentItem()
        if not item:
            QMessageBox.warning(self, "Аккаунт", "Выберите аккаунт.")
            return None
        return self.con.execute(
            "SELECT * FROM accounts WHERE id=?", (item.data(256),)
        ).fetchone()

    def selected_changed(self):
        r = self.current()
        if r:
            self.info.setText(f"Выбран: {r['name']}")

    def add_account(self):
        d = AccountDialog(self)
        if d.exec() != QDialog.Accepted:
            return
        try:
            v = d.values()
            session = "account_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            self.con.execute(
                """INSERT INTO accounts
                (name,api_id,api_hash,phone,proxy_host,proxy_port,
                 proxy_user,proxy_pass,session)
                VALUES(?,?,?,?,?,?,?,?,?)""",
                (v["name"], v["api_id"], v["api_hash"], v["phone"],
                 v["host"], v["port"], v["user"], v["pw"], session)
            )
            self.con.commit()
            self.load_accounts()
            self.log("Добавлен аккаунт: " + v["name"])
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def remove_account(self):
        r = self.current()
        if r and QMessageBox.question(
            self, "Удаление", f"Удалить {r['name']}?"
        ) == QMessageBox.Yes:
            self.con.execute("DELETE FROM accounts WHERE id=?", (r["id"],))
            self.con.commit()
            self.load_accounts()

    def start(self, mode, payload=None):
        r = self.current()
        if not r:
            return
        self.worker = Worker(r, mode, payload)
        self.worker.log.connect(self.log)
        self.worker.dialogs.connect(self.set_dialogs)
        self.worker.rows.connect(self.set_rows)
        self.worker.code_needed.connect(self.ask_code)
        self.worker.password_needed.connect(self.ask_password)
        self.worker.start()

    def authorize(self):
        self.start("auth")

    def ask_code(self, worker):
        code, ok = QInputDialog.getText(
            self, "Код Telegram", "Введите код из Telegram:"
        )
        if ok:
            worker.code = code

    def ask_password(self, worker):
        password, ok = QInputDialog.getText(
            self, "2FA", "Введите пароль двухфакторной аутентификации:",
            QLineEdit.Password
        )
        if ok:
            worker.password = password

    def load_dialogs(self):
        self.start("dialogs")

    def set_dialogs(self, items):
        self.chat.clear()
        for x in items:
            self.chat.addItem(f"{x['name']} [{x['id']}]", x["id"])

    def parse(self):
        chat = self.chat.currentData()
        if chat is None:
            chat = self.chat.currentText().strip()
        if not chat:
            QMessageBox.warning(self, "Чат", "Выберите чат.")
            return
        self.start("parse", {
            "chat": chat,
            "limit": self.limit.value(),
            "keyword": self.keyword.text()
        })

    def set_rows(self, rows):
        self.results = rows
        self.table.setRowCount(0)
        for r in rows:
            i = self.table.rowCount()
            self.table.insertRow(i)
            for j, value in enumerate([
                r["account"], r["chat"], r["message_id"],
                r["sender"], r["date"], r["text"]
            ]):
                self.table.setItem(i, j, QTableWidgetItem(str(value)))

    def export_csv(self):
        if not self.results:
            QMessageBox.information(self, "Экспорт", "Нет результатов.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "CSV", str(DATA / "results.csv"), "CSV (*.csv)"
        )
        if path:
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                w = csv.DictWriter(f, fieldnames=self.results[0].keys())
                w.writeheader()
                w.writerows(self.results)

    def export_json(self):
        if not self.results:
            QMessageBox.information(self, "Экспорт", "Нет результатов.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "JSON", str(DATA / "results.json"), "JSON (*.json)"
        )
        if path:
            Path(path).write_text(
                json.dumps(self.results, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setApplicationName("Telegram Parser")
    w = Main()
    w.show()
    sys.exit(app.exec())
